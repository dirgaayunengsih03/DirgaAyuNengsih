package com.example.utsmobileprograming

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Ustad(
    val name: String,
    val description: String,
    val photo: Int,
    val keterangan: String  // Tambahkan ini
) : Parcelable